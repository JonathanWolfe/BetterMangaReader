module.exports = {
	"manga here": require('./mirrors/mangahere'),
	"mangastream": require('./mirrors/mangastream')
}